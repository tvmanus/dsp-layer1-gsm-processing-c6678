/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z63
 */

#ifndef myBoard_Core5_m__
#define myBoard_Core5_m__



#endif /* myBoard_Core5_m__ */ 
