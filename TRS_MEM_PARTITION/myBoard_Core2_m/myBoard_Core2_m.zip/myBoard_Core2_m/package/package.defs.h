/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z63
 */

#ifndef myBoard_Core2_m__
#define myBoard_Core2_m__



#endif /* myBoard_Core2_m__ */ 
