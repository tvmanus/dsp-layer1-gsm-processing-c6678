/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z63
 */

#ifndef myBoard_Core0_m__
#define myBoard_Core0_m__



#endif /* myBoard_Core0_m__ */ 
